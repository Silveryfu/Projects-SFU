You may:
-Double click Run.bat to encode.
-using command "java ChordDHT"

-input data is stored in file "dht.in"
-output data is store in file "dht.out"
 
**make sure JRE is installed and under the system path!