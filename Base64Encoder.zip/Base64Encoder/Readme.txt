You may:
-Double click Run.bat to encode.
-using command "java Base64Encoder"

-input data is stored in file "data.in"
-output data (encoded) is store in file "data.out"
 
**make sure JRE is installed and under the system path!