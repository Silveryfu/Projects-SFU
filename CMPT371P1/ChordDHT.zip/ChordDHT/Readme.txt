You may:
-Double click Run.bat to encode.
-using command "java ChordDHT"

-input data is stored in file "dht.in"
-output data is store in file "dht.out"

-the example provided gives a hashspace of size 1024, start querying from node 1
 
**make sure JRE is installed and under the system path!

